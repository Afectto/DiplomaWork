﻿public class GameState : IGameState
{
    public void Enter()
    {
    }

    public void Exit()
    {
    }
}