﻿public enum GameStateData
{
    Game,
    Pause,
    Quest,
    GameOver
}