﻿public class LevelSettings
{
    public GridSetting SettingGrid { get; set; }
    public int MinTasksDifficulty { get; set; }
    public int MaxTasksDifficulty { get; set; }
    public int WallCount { get; set; }
    public int DangerPointsCount { get; set; }
    public int InterestPointsCount { get; set; }
}