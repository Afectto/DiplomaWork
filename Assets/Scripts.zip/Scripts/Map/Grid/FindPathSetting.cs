﻿public struct FindPathSetting
{
    public int StartX;
    public int StartY;
    public int EndX;
    public int EndY;
    public bool[] IsWalkableArray;
}