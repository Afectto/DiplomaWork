﻿using UnityEngine;

public interface ITargetable
{
    public Transform Transform { get; }
}