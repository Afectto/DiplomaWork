﻿public enum SceneType
{
    Menu,
    Game,
    Loading,
}