﻿public interface ISaveData
{
}
