﻿public enum SoundType
{
    Click,
    ExplosionBarrier,
    ExplosionBall,
    CollectCoin,
    HitLine,
    HitBall,
    Teleport,
}