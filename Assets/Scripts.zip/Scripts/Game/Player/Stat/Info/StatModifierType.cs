﻿public enum StatModifierType
{
    Additive,
    Multiplicative,
    PercentDecrease
}